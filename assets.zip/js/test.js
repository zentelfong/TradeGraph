import {Window,Controller,WindowFlags,log,quit} from "sgui";
import { format } from "./format.js"

globalThis.print = function() {
	log(format.apply(null, arguments));
}

print("runjs");

class TestController extends Controller{
	
	constructor(){
		super();
		this.loadXmlFile("image.xml");
	}
	
	onEvent(event){
		let sender = event.sender;
		if(sender.id == "sys_close"){
			quit();
		}
		print(event.type);
	}
}

class TestWindow extends Window{
	constructor(){
		super();
		this.controller = new TestController();
		this.setMinSize(600,480);
		this.setCaption(0,30,0,0);
	}
	
	onEvent(event){
		print("window event:",event);
	}
}

let window = new TestWindow();
window.createWindow(null,[0,0,800,600],WindowFlags.show | 
    WindowFlags.resizable | WindowFlags.center | WindowFlags.borderless)


//防止被释放
globalThis.window = window;
